package com.minh.simpleService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
