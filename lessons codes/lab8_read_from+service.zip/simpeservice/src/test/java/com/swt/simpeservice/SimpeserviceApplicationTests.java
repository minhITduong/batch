package com.swt.simpeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpeserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
