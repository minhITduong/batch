package com.swt.simpeservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpeserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(SimpeserviceApplication.class, args);
    }

}
